package com.shophubpro.stepdefinitions;

import com.shophubpro.core.Config;
import com.shophubpro.core.DriverFactory;
import io.cucumber.java.*;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

public class Hooks {

    @Before
    public void beforeScenario(Scenario scenario){
        String browser = Config.get("browser", "chrome");
        boolean headless = Boolean.parseBoolean(Config.get("headless", "false"));
        DriverFactory.initDriver(browser, headless);
    }

    @After
    public void afterScenario(Scenario scenario){
        if (scenario.isFailed()){
            byte[] shot = ((TakesScreenshot)DriverFactory.getDriver()).getScreenshotAs(OutputType.BYTES);
            scenario.attach(shot, "image/png", "failure");
        }
        DriverFactory.quitDriver();
    }
}