package com.shophubpro.pages;

import org.openqa.selenium.*;
import java.util.List;
import java.util.ArrayList;

public class LoginPage extends BasePage {

    public LoginPage(WebDriver driver) { super(driver); }

    private WebElement usernameField(){
        List<By> tries = new ArrayList<>();
        tries.add(By.cssSelector("input[type='email']"));
        tries.add(By.cssSelector("input[name*='email' i]"));
        tries.add(By.cssSelector("input[id*='email' i]"));
        tries.add(By.cssSelector("input[name*='user' i]"));
        tries.add(By.cssSelector("input[id*='user' i]"));
        tries.add(By.xpath("//input[@placeholder='Email' or @placeholder='E-mail' or @placeholder='Username']"));
        return firstPresent(tries);
    }

    private WebElement passwordField(){
        List<By> tries = new ArrayList<>();
        tries.add(By.cssSelector("input[type='password']"));
        tries.add(By.cssSelector("input[name*='pass' i]"));
        tries.add(By.cssSelector("input[id*='pass' i]"));
        tries.add(By.xpath("//input[@placeholder='Password']"));
        return firstPresent(tries);
    }

    private WebElement loginButton(){
        List<By> tries = new ArrayList<>();
        tries.add(By.cssSelector("button[type='submit']"));
        tries.add(By.xpath("//button[contains(.,'Login') or contains(.,'Sign in') or contains(.,'Log in')]"));
        tries.add(By.xpath("//input[@type='submit']"));
        return firstPresent(tries);
    }

    private WebElement errorBanner(){
        List<By> tries = new ArrayList<>();
        tries.add(By.cssSelector(".error, .alert-danger, .error-message"));
        tries.add(By.xpath("//*[contains(@class,'error') or contains(@class,'alert')][1]"));
        return firstPresent(tries);
    }

    public void open(){ driver.get("https://bugbash.syook.com/"); }

    public void login(String user, String pass){
        WebElement u = usernameField();
        u.clear(); u.sendKeys(user == null ? "" : user);
        WebElement p = passwordField();
        p.clear(); p.sendKeys(pass == null ? "" : pass);
        loginButton().click();
    }

    public boolean isErrorVisible(){
        try { return errorBanner().isDisplayed(); }
        catch (NoSuchElementException e){ return false; }
    }

    public void assertOnHome(){ waitForUrlContains("dashboard"); }
}