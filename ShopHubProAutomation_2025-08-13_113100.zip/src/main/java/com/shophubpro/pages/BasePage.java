package com.shophubpro.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;

import java.util.Arrays;
import java.util.List;

public class BasePage {
    protected WebDriver driver;

    public BasePage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    protected WebElement firstPresent(List<By> locators){
        for(By by : locators){
            try {
                WebElement el = driver.findElement(by);
                if(el.isDisplayed()) return el;
            } catch (NoSuchElementException ignored){}
        }
        throw new NoSuchElementException("None of the locators matched: " + Arrays.toString(locators.toArray()));
    }

    protected void waitForUrlContains(String part){
        long end = System.currentTimeMillis() + 10000;
        while(System.currentTimeMillis() < end){
            if(driver.getCurrentUrl().toLowerCase().contains(part.toLowerCase())) return;
            try { Thread.sleep(200); } catch (InterruptedException ignored){}
        }
        throw new TimeoutException("URL did not contain '" + part + "'");
    }
}