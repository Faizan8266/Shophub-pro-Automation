package com.shophubpro.core;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Config {
    private static final Properties props = new Properties();

    static {
        try (FileInputStream fis = new FileInputStream("src/test/resources/config.properties")){
            props.load(fis);
        } catch (IOException e){
            // default values used if file not found
        }
    }

    public static String get(String key, String def){
        String sys = System.getProperty(key);
        if(sys != null && !sys.isEmpty()) return sys;
        return props.getProperty(key, def);
    }
}