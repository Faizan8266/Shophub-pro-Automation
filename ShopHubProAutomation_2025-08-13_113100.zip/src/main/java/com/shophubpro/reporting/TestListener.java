package com.shophubpro.reporting;

import org.testng.*;

public class TestListener implements ITestListener, ISuiteListener { }